result.Turtle=require('./turtle');
result.WaterTurtle=require('./waterturtle');
result.GalapagosTurtle=require('./galapagosturtle');
result.EvkodianTurtle=require('./evkodianturtle');
result.NinjaTurtle=require('./ninjaturtle');

/*
import {Turtle} from './turtle';
import {WaterTurtle} from './waterturtle';
import {GalapagosTurtle} from './galapagosturtle';
import {EvkodianTurtle} from './evkodianturtle';
import {NinjaTurtle} from './ninjaturtle';

result.Turtle=Turtle;
result.WaterTurtle=WaterTurtle;
result.GalapagosTurtle=GalapagosTurtle;
result.EvkodianTurtle=EvkodianTurtle;
result.NinjaTurtle=NinjaTurtle;

*/