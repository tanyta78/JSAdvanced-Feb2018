let Checkbox = require('./checkbox');
let Numberbox = require('./numberbox');

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;
