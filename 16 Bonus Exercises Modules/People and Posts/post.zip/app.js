result.Post = require('./post');
result.Person = require('./person');